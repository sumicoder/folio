import { animation } from './_animation';
import { resize } from './_resize_auto_reload';
import { slider } from './_slider';

animation();
resize();
slider();