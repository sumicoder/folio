<?php get_header(); ?>
<div class="page-404">
  <p class="page-404__text">404 ERRER</p>
  <a class="btn-back" href="<?php echo home_url(); ?>">トップへ戻る</a>
</div>
<?php get_footer(); ?>